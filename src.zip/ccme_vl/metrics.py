import string
from typing import List, Tuple
import torch

VQA_PROMPT_TPL = "USER: <image>\n{q}\nASSISTANT:"   # works for LLaVA-style
INSTRUCTBLIP_TPL = "Question: {q}\nAnswer:"

# def make_vqa_prompt(question: str, model_id: str) -> str:
#     q = question.strip()
#     mid = (model_id or "").lower()
#     if "llava" in mid:
#         return VQA_PROMPT_TPL.format(q=q)
#     else:
#         # BLIP-2 / InstructBLIP style
#         return INSTRUCTBLIP_TPL.format(q=q)
def make_vqa_prompt(question: str, model_id: str) -> str:
    """
    Decide prompt style depending on model type.
    """
    q = question.strip()
    mid = (model_id or "").lower()
    if "llava" in mid:
        return f"USER: <image>\n{q}\nASSISTANT:"
    else:
        # default for BLIP-2 / InstructBLIP
        return f"Question: {q}\nAnswer:"


def generate_answer(model, processor, image, question: str, max_new_tokens=8, model_id: str = "") -> str:
    """
    Generate an answer from the VQA model.
    model_id is used to decide prompt format.
    """
    prompt = make_vqa_prompt(question, model_id)
    inputs = processor(images=image, text=prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            num_beams=3,
            do_sample=False,
            length_penalty=0.0,
            repetition_penalty=1.1,
        )
    return processor.tokenizer.decode(out[0], skip_special_tokens=True).strip()




def answer_nll(model, processor, image, question: str, answer: str) -> float:
    inputs = processor(images=image, text=question, return_tensors="pt").to(model.device)
    labels = processor.tokenizer(answer, return_tensors="pt").input_ids.to(model.device)
    with torch.no_grad():
        loss = model(**inputs, labels=labels).loss
    return float(loss.item())

def simple_tokenize(question: str) -> List[str]:
    q = question.strip()
    q = q.translate(str.maketrans("", "", string.punctuation.replace("'", "")))
    return [t for t in q.split() if t]

def is_stopword(tok: str) -> bool:
    SW = {
        "a","an","the","is","are","was","were","do","does","did","of","to","for","and","or","on",
        "in","at","by","with","from","what","which","who","whom","whose","where","when","how","why"
    }
    return tok.lower() in SW


def text_side_causal_importance(model, processor, image, question: str, baseline_answer: str) -> List[Tuple[str,float]]:
    toks = simple_tokenize(question)
    base_nll = answer_nll(model, processor, image, question, baseline_answer)
    results = []
    for i, tok in enumerate(toks):
        if is_stopword(tok) or len(tok) <= 1:
            continue
        q_masked = " ".join([t for j,t in enumerate(toks) if j != i])
        nll = answer_nll(model, processor, image, q_masked, baseline_answer)
        results.append((tok, float(nll - base_nll)))
    results.sort(key=lambda x: x[1], reverse=True)
    return results
