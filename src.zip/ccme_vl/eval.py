import collections, string
from typing import List
import numpy as np

def normalize_str(s: str) -> str:
    s = s.lower().strip()
    tbl = str.maketrans("", "", string.punctuation)
    s = s.translate(tbl)
    s = " ".join(s.split())
    return s

# VQAv2 soft accuracy: min( #humans that said pred / 3 , 1 )
def vqa_soft_acc(pred: str, answers: List[str]) -> float:
    p = normalize_str(pred)
    cnt = sum(1 for a in answers if normalize_str(a) == p)
    return min(1.0, cnt / 3.0)

def deletion_auc_from_deltas(deltas: List[float], steps: int = 8) -> float:
    arr = np.array(sorted(deltas, reverse=True))
    k = min(len(arr), steps)
    xs = np.linspace(0, 1, k+1)
    ys = np.concatenate([[0.0], np.cumsum(arr[:k])])
    if ys[-1] > 0: ys = ys / (ys[-1] + 1e-9)
    return float(np.trapz(ys, xs))
