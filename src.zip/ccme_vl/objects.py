import torch, torchvision
import torchvision.transforms as T
from typing import List, Tuple
from PIL import Image

_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
_model = None
_tf = T.Compose([T.ToTensor()])

def _load():
    global _model
    if _model is None:
        _model = torchvision.models.detection.fasterrcnn_resnet50_fpn(weights="DEFAULT").to(_device).eval()
    return _model

def detect_boxes(img: Image.Image, score_thr: float = 0.7) -> List[Tuple[int,int,int,int,int]]:
    """
    Returns list of (x0,y0,x1,y1,label) with COCO labels (1=person, etc.)
    """
    model = _load()
    x = _tf(img).to(_device)
    with torch.no_grad():
        pred = model([x])[0]
    boxes = pred["boxes"].detach().cpu().numpy()
    scores = pred["scores"].detach().cpu().numpy()
    labels = pred["labels"].detach().cpu().numpy()
    out = []
    for b, s, l in zip(boxes, scores, labels):
        if s >= score_thr:
            x0,y0,x1,y1 = b.astype(int).tolist()
            out.append((x0,y0,x1,y1,int(l)))
    return out
