from PIL import Image, ImageDraw

def draw_grid(img: Image.Image, rows: int, cols: int) -> Image.Image:
    out = img.copy()
    draw = ImageDraw.Draw(out)
    w, h = img.size
    for c in range(1, cols):
        x = int(c * w / cols)
        draw.line([(x, 0), (x, h)], fill=(255,255,255), width=1)
    for r in range(1, rows):
        y = int(r * h / rows)
        draw.line([(0, y), (w, y)], fill=(255,255,255), width=1)
    return out
