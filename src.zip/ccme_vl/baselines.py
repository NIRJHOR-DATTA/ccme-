from typing import List, Tuple, Optional
import numpy as np
import torch
from PIL import Image, ImageFilter

from .metrics import answer_nll
from .masking import mask_image_region

# ---------------------------
# 1) Our method: ΔNLL per box
# ---------------------------
def rank_image_regions_delta_nll(model, processor, img: Image.Image, question: str,
                                 baseline_answer: str, boxes: List[Tuple[int,int,int,int]],
                                 mask_mode: str = "blur") -> Tuple[List[float], float]:
    base_nll = answer_nll(model, processor, img, question, baseline_answer)
    scores = []
    for box in boxes:
        masked = mask_image_region(img, box, mode=mask_mode)
        nll = answer_nll(model, processor, masked, question, baseline_answer)
        scores.append(float(nll - base_nll))
    return scores, base_nll

# ---------------------------------
# 2) Vanilla Gradients on pixel grid
#    (saliency = |∂loss/∂pixel| * pixel)
# ---------------------------------
def rank_image_regions_grad(model, processor, img: Image.Image, question: str,
                            baseline_answer: str, boxes: List[Tuple[int,int,int,int]]) -> Tuple[List[float], float]:
    model.eval()
    inputs = processor(images=img, text=question, return_tensors="pt")
    device = next(model.parameters()).device
    # keep dtype consistent with model
    pixel_values = inputs.pop("pixel_values").to(device)
    pixel_values.requires_grad_(True)
    for k in list(inputs.keys()):
        inputs[k] = inputs[k].to(device)

    labels = processor.tokenizer(baseline_answer, return_tensors="pt").input_ids.to(device)
    with torch.enable_grad():
        outputs = model(pixel_values=pixel_values, **inputs, labels=labels)
        loss = outputs.loss
        base_nll = float(loss.item())
        loss.backward()

    grad = pixel_values.grad.detach()                    # [1,C,H,W]
    sal = (grad.abs() * pixel_values.detach().abs()).mean(dim=1)[0]  # [H,W]
    sal = sal.cpu().numpy()
    sal = (sal - sal.min()) / (sal.max() - sal.min() + 1e-8)

    scores = []
    for (x0,y0,x1,y1) in boxes:
        patch = sal[y0:y1, x0:x1]
        scores.append(float(patch.mean()))
    # normalize to look like ΔNLL-ish scale (optional)
    scores = list((np.array(scores) - np.min(scores)) / (np.max(scores) - np.min(scores) + 1e-8))
    return scores, base_nll

# ------------------------
# 3) RISE (random masking)
#    (Petsiuk et al. ECCV'18)
# ------------------------
def _random_masks(h, w, N=64, cell=8, p=0.5):
    """
    Sample N random binary masks at coarse grid 'cell'x'cell', then upsample to h x w.
    Returns [N, h, w] in float32 (0..1).
    """
    masks = []
    for _ in range(N):
        g = (np.random.rand(cell, cell) < p).astype(np.float32)
        m = Image.fromarray((g*255).astype(np.uint8)).resize((w, h), Image.NEAREST)
        masks.append(np.array(m, dtype=np.float32) / 255.0)
    return np.stack(masks, axis=0)  # [N, h, w]

def rank_image_regions_rise(model, processor, img: Image.Image, question: str,
                            baseline_answer: str, boxes: List[Tuple[int,int,int,int]],
                            N=64, cell=8, p=0.5, blur_bg=True) -> Tuple[List[float], float]:
    base_nll = answer_nll(model, processor, img, question, baseline_answer)

    W, H = img.size
    masks = _random_masks(H, W, N=N, cell=cell, p=p)      # [N,H,W]
    scores = np.zeros((H, W), dtype=np.float32)
    weights = np.zeros((H, W), dtype=np.float32)

    for i in range(N):
        m = masks[i]
        if blur_bg:
            bg = img.filter(ImageFilter.GaussianBlur(radius=12))
            comp = Image.composite(img, bg, Image.fromarray((m*255).astype(np.uint8)))
        else:
            comp_np = (np.array(img).astype(np.float32) * m[..., None]).astype(np.uint8)
            comp = Image.fromarray(comp_np)

        nll = answer_nll(model, processor, comp, question, baseline_answer)
        delta = float(nll - base_nll)
        scores += m * delta
        weights += m

    sal = scores / (weights + 1e-8)                       # [H,W]
    sal = (sal - sal.min()) / (sal.max() - sal.min() + 1e-8)

    cell_scores = []
    for (x0,y0,x1,y1) in boxes:
        patch = sal[y0:y1, x0:x1]
        cell_scores.append(float(patch.mean()))
    return cell_scores, base_nll

# --------------------
# 4) Random / Uniform
# --------------------
def rank_image_regions_random(boxes: List[Tuple[int,int,int,int]]) -> Tuple[List[float], float]:
    s = np.random.rand(len(boxes)).astype(np.float32).tolist()
    return s, 0.0

def rank_image_regions_uniform(boxes: List[Tuple[int,int,int,int]]) -> Tuple[List[float], float]:
    return [1.0 for _ in boxes], 0.0
