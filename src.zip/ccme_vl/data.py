import os, json, re
from typing import List, Dict, Optional, Iterator
from dataclasses import dataclass

_QNORM = re.compile(r"[^a-z0-9 ]+")

def _norm(s: str) -> str:
    if s is None: return ""
    s = s.lower().strip()
    s = _QNORM.sub(" ", s)
    return " ".join(s.split())

@dataclass
class Sample:
    image_path: str
    question: str
    answers: List[str]         # all 10 human answers (normalized)
    qid: str

class VQAv2Dataset:
    """
    ann_path: annotations/v2_mscoco_val2014_annotations.json
    ques_path: questions/v2_OpenEnded_mscoco_val2014_questions.json
    img_root:  MSCOCO val2014 images folder
    """
    def __init__(self, ann_path: str, ques_path: str, img_root: str):
        with open(ann_path, "r") as f:
            anns = json.load(f)["annotations"]
        with open(ques_path, "r") as f:
            ques = json.load(f)["questions"]
        qmap = {q["question_id"]: q for q in ques}
        self.samples: List[Sample] = []
        for a in anns:
            qid = a["question_id"]
            qobj = qmap[qid]
            img_file = f"COCO_val2014_{a['image_id']:012d}.jpg"
            img_path = os.path.join(img_root, img_file)
            answers = [_norm(x["answer"]) for x in a.get("answers", [])]
            self.samples.append(Sample(
                image_path=img_path,
                question=qobj["question"],
                answers=answers if answers else [""],
                qid=str(qid)
            ))
    def __len__(self): return len(self.samples)
    def __iter__(self): return iter(self.samples)
