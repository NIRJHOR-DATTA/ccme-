from transformers import (
    Blip2ForConditionalGeneration,
    InstructBlipForConditionalGeneration,
    AutoProcessor,
    InstructBlipProcessor,
)
import torch

DEFAULT_MODEL_ID = "Salesforce/blip2-flan-t5-xl"

def load_blip2(model_id: str = DEFAULT_MODEL_ID):
    mid = (model_id or "").lower()
    kwargs = {}
    if torch.cuda.is_available():
        kwargs.update(dict(device_map="auto", torch_dtype=torch.float16))
    else:
        kwargs.update(dict(device_map=None, torch_dtype=torch.float32))

    # Choose correct pair
    if "instructblip" in mid:
        processor = InstructBlipProcessor.from_pretrained(model_id)
        model = InstructBlipForConditionalGeneration.from_pretrained(model_id, **kwargs)
    else:
        # BLIP-2 (Flan-T5, OPT, etc.) should use AutoProcessor, NOT BlipProcessor
        processor = AutoProcessor.from_pretrained(model_id)
        model = Blip2ForConditionalGeneration.from_pretrained(model_id, **kwargs)

    return model, processor
