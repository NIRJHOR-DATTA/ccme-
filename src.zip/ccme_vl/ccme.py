from typing import Tuple, List
import numpy as np
from .metrics import generate_answer, answer_nll, text_side_causal_importance
from .masking import grid_boxes, mask_image_region

def image_side_causal_importance(model, processor, img, question: str, baseline_answer: str,
                                 rows=4, cols=4) -> Tuple[List[float], float, List[tuple]]:
    base_nll = answer_nll(model, processor, img, question, baseline_answer)
    w, h = img.size
    boxes = grid_boxes(w, h, rows, cols)
    deltas = []
    for box in boxes:
        masked = mask_image_region(img, box, fill=(128,128,128))
        nll = answer_nll(model, processor, masked, question, baseline_answer)
        deltas.append(nll - base_nll)
    return deltas, base_nll, boxes

def topk_indices(arr: List[float], k: int) -> List[int]:
    idx = np.argsort(np.array(arr))[::-1]
    return [int(i) for i in idx[:k]]
