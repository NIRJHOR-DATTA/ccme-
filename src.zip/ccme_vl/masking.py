from typing import Tuple, List
from PIL import Image, ImageDraw
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
def preprocess_image(path: str, max_size: int = 1024) -> Image.Image:
    img = Image.open(path).convert("RGB")
    w, h = img.size
    scale = min(1.0, max_size / max(w, h))
    if scale < 1.0:
        img = img.resize((int(w*scale), int(h*scale)))
    return img

def grid_boxes(w: int, h: int, rows: int, cols: int) -> List[Tuple[int,int,int,int]]:
    boxes = []
    for r in range(rows):
        for c in range(cols):
            x0 = int(c * w / cols); x1 = int((c+1) * w / cols)
            y0 = int(r * h / rows); y1 = int((r+1) * h / rows)
            boxes.append((x0,y0,x1,y1))
    return boxes



def mask_image_region(img, box, fill=(128,128,128), mode="blur"):
    if mode == "blur":
        masked = img.copy()
        patch = masked.crop(box).filter(ImageFilter.GaussianBlur(radius=7))
        masked.paste(patch, box[:2])
        return masked
    else:
        masked = img.copy()
        ImageDraw.Draw(masked).rectangle(box, fill=fill)
        return masked

from PIL import Image, ImageDraw, ImageFilter

def mask_image_region(img, box, fill=(128,128,128), mode="blur"):
    if mode == "blur":
        masked = img.copy()
        patch = masked.crop(box).filter(ImageFilter.GaussianBlur(radius=7))
        masked.paste(patch, box[:2])
        return masked
    else:
        masked = img.copy()
        ImageDraw.Draw(masked).rectangle(box, fill=fill)
        return masked

def overlay_heatmap(img: Image.Image, rows: int, cols: int, scores: List[float]) -> Image.Image:
    w, h = img.size
    arr = np.array(img).astype(np.float32) / 255.0
    scores = np.array(scores, dtype=np.float32)
    if scores.size and scores.max() > scores.min():
        norm = (scores - scores.min()) / (scores.max() - scores.min() + 1e-8)
    else:
        norm = np.zeros_like(scores)

    overlay = np.zeros_like(arr)
    k = 0
    for r in range(rows):
        for c in range(cols):
            x0 = int(c * w / cols); x1 = int((c+1) * w / cols)
            y0 = int(r * h / rows); y1 = int((r+1) * h / rows)
            val = float(norm[k]); k += 1
            overlay[y0:y1, x0:x1, 0] = val  # red channel

    alpha = 0.45
    out = (1 - alpha) * arr + alpha * overlay
    out = (np.clip(out, 0, 1) * 255).astype(np.uint8)
    return Image.fromarray(out)
