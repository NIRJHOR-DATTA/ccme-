import os, argparse, csv
import networkx as nx

from ccme_vl.model_loader import load_blip2, DEFAULT_MODEL_ID
from ccme_vl.masking import preprocess_image, grid_boxes, mask_image_region, overlay_heatmap
from ccme_vl.metrics import generate_answer, answer_nll, simple_tokenize, is_stopword
from ccme_vl.ccme import image_side_causal_importance

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--question", required=True)
    ap.add_argument("--out_dir", default="runs/graph")
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--max_new_tokens", type=int, default=10)
    ap.add_argument("--model_id", type=str, default=DEFAULT_MODEL_ID)
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    model, processor = load_blip2(args.model_id)
    img = preprocess_image(args.image)

    # baseline prediction & loss
    ans = generate_answer(model, processor, img, args.question, max_new_tokens=args.max_new_tokens)
    base_nll = answer_nll(model, processor, img, args.question, ans)

    # image deltas
    img_scores, _, boxes = image_side_causal_importance(model, processor, img, args.question, ans,
                                                        rows=args.rows, cols=args.cols)
    overlay_heatmap(img, args.rows, args.cols, img_scores).save(os.path.join(args.out_dir, "image_importance_overlay.png"))

    # token deltas
    toks = [t for t in simple_tokenize(args.question) if (not is_stopword(t) and len(t) > 1)]
    token_deltas = {}
    for i, t in enumerate(toks):
        q_drop = " ".join([x for x in toks if x != t])
        nll = answer_nll(model, processor, img, q_drop, ans)
        token_deltas[t] = nll - base_nll

    # pairwise synergy S(t, r)
    G = nx.Graph()
    for t in toks:
        G.add_node(f"T:{t}", bipartite=0)
    for ridx in range(len(boxes)):
        G.add_node(f"R:{ridx}", bipartite=1)

    rows = []
    for t in toks:
        for ridx, box in enumerate(boxes):
            # mask token t
            q_drop = " ".join([x for x in toks if x != t])
            # mask region r
            img_r = mask_image_region(img, box)
            # ΔNLL for pair masking
            nll_pair = answer_nll(model, processor, img_r, q_drop, ans)
            pair_delta = nll_pair - base_nll
            synergy = token_deltas[t] + img_scores[ridx] - pair_delta
            G.add_edge(f"T:{t}", f"R:{ridx}", weight=float(synergy))
            rows.append((t, ridx, float(synergy)))

    # save edges
    tsv_path = os.path.join(args.out_dir, "bipartite_edges.tsv")
    with open(tsv_path, "w", newline="") as f:
        cw = csv.writer(f, delimiter="\t")
        cw.writerow(["token", "region_index", "synergy"])
        cw.writerows(rows)

    # print top-10
    rows.sort(key=lambda x: x[2], reverse=True)
    with open(os.path.join(args.out_dir, "bipartite_summary.txt"), "w") as f:
        for t, ridx, s in rows[:10]:
            f.write(f"{t}\tregion{ridx}\tsynergy={s:.4f}\n")

    print(f"Saved → {tsv_path}")

if __name__ == "__main__":
    main()
