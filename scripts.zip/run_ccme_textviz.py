# scripts/run_ccme_textviz.py
import os, argparse, json, html
from pathlib import Path

from PIL import Image
from ccme_vl.model_loader import load_blip2, DEFAULT_MODEL_ID
from ccme_vl.masking import preprocess_image, overlay_heatmap, mask_image_region
from ccme_vl.metrics import generate_answer, answer_nll, text_side_causal_importance
from ccme_vl.ccme import image_side_causal_importance, topk_indices

# ------------------------- HTML helpers -------------------------
def _norm_scores(pairs):
    # pairs: List[(token, score)]
    if not pairs:
        return pairs, 0.0, 0.0
    vals = [s for _, s in pairs]
    lo, hi = min(vals), max(vals)
    rng = hi - lo if hi != lo else 1e-8
    normed = [(tok, (s - lo) / rng) for tok, s in pairs]
    return normed, lo, hi

def _color_for(val):
    """
    Map [0,1] -> heat color (blue->yellow->red).
    Simple 3-stop gradient: (0.0:#2b6cb0) -> (0.5:#f6e05e) -> (1.0:#e53e3e)
    """
    # Piecewise linear interpolation
    if val <= 0.5:
        # blue -> yellow
        t = val / 0.5
        c1 = (0x2b, 0x6c, 0xb0)   # #2b6cb0
        c2 = (0xf6, 0xe0, 0x5e)   # #f6e05e
    else:
        # yellow -> red
        t = (val - 0.5) / 0.5
        c1 = (0xf6, 0xe0, 0x5e)   # #f6e05e
        c2 = (0xe5, 0x3e, 0x3e)   # #e53e3e
    r = int(c1[0] + t * (c2[0]-c1[0]))
    g = int(c1[1] + t * (c2[1]-c1[1]))
    b = int(c1[2] + t * (c2[2]-c1[2]))
    return f"#{r:02x}{g:02x}{b:02x}"

def visualize_text_html(question, text_scores, topk=3, show_bars=True):
    """
    Build an HTML snippet with tokens colored by normalized ΔNLL and
    top-k bolded. Also optionally adds tiny bars under tokens.
    """
    # text_scores is already tokenized list [(token, delta_nll), ...] from your pipeline
    normed, lo, hi = _norm_scores(text_scores)

    # pick top-k by raw ΔNLL (not normalized)
    top_sorted = sorted(text_scores, key=lambda x: x[1], reverse=True)
    top_set = set(tok for tok, _ in top_sorted[:max(0, topk)])

    spans = []
    for tok, raw in text_scores:
        # find normalized value for same token index
        # (assumes identical order; safe with your text_side_causal_importance)
        # lookup normalized val by walking normed in parallel
        # safer: recompute normalization positionally
        # NOTE: we reuse zip to ensure alignment
        break

    # alignment-safe reconstruction
    norm_map = []
    for (tok1, raw1), (_, nrm) in zip(text_scores, normed):
        norm_map.append((tok1, raw1, nrm))

    # build tokens row
    token_spans = []
    for tok, raw, nrm in norm_map:
        esc = html.escape(tok)
        color = _color_for(nrm)
        weight = "700" if tok in top_set else "400"
        token_spans.append(
            f"<span style='padding:1px 3px; margin:2px; border-radius:4px; "
            f"background:{color}22; color:#111; font-weight:{weight}; "
            f"border:1px solid {color}55'>{esc}</span>"
        )
    tokens_line = "<div style='font-family:Inter,Segoe UI,Arial,sans-serif; line-height:1.9;'>" + " ".join(token_spans) + "</div>"

    bars_line = ""
    if show_bars:
        bars = []
        for tok, raw, nrm in norm_map:
            w = int(4 + 96 * nrm)  # 4..100px
            color = _color_for(nrm)
            bars.append(
                f"<div style='display:inline-block; width:{w}px; height:6px; "
                f"background:{color}; margin:0 6px 0 0; border-radius:3px;'></div>"
            )
        bars_line = "<div style='margin-top:6px;'>" + "".join(bars) + "</div>"

    legend = (
        "<div style='font-size:12px; color:#444; margin-top:8px;'>"
        "Colors reflect normalized ΔNLL importance (blue→yellow→red). "
        f"Min={lo:.4f}, Max={hi:.4f}. Bold tokens are top-k by ΔNLL."
        "</div>"
    )

    html_block = (
        "<div style='border:1px solid #ddd; border-radius:8px; padding:10px; background:#fafafa;'>"
        "<div style='font-weight:600; margin-bottom:6px;'>Text Attribution (ΔNLL)</div>"
        f"{tokens_line}{bars_line}{legend}</div>"
    )
    return html_block

# ------------------------- main -------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--question", required=True)
    ap.add_argument("--out_dir", default="runs/demo_textviz")
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--max_new_tokens", type=int, default=8)
    ap.add_argument("--model_id", type=str, default=DEFAULT_MODEL_ID)
    ap.add_argument("--iterative_delete", type=int, default=0,
                    help="Mask top-K cells sequentially before counterfactual generation (0 = single top cell)")
    ap.add_argument("--mask_mode", type=str, default="blur",
                    choices=["blur", "gray", "black"], help="Masking style for perturbations")
    ap.add_argument("--topk_tokens", type=int, default=3, help="Top-k tokens to bold")
    ap.add_argument("--save_json", action="store_true", help="Also save a JSON dump with token ΔNLL scores")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    print(f"[INFO] Loading model: {args.model_id}")
    model, processor = load_blip2(args.model_id)

    print("[INFO] Reading image...")
    img = preprocess_image(args.image)

    print("[INFO] Baseline generation...")
    ans = generate_answer(
        model, processor, img, args.question,
        max_new_tokens=args.max_new_tokens, model_id=args.model_id
    )
    base_nll = answer_nll(model, processor, img, args.question, ans)
    print(f"\nQ: {args.question}\nA (baseline): {ans}\nBaseline NLL: {base_nll:.4f}")

    print("[INFO] Image-side importance...")
    img_scores, _, boxes = image_side_causal_importance(
        model, processor, img, args.question, ans, rows=args.rows, cols=args.cols
    )
    overlay = overlay_heatmap(img, args.rows, args.cols, img_scores)
    overlay_path = os.path.join(args.out_dir, "image_importance_overlay.png")
    overlay.save(overlay_path)
    print(f"Saved → {overlay_path}")

    idx_sorted = topk_indices(img_scores, k=min(5, len(img_scores)))
    print("\nTop image cells by ΔNLL:")
    for rank, i in enumerate(idx_sorted, 1):
        r, c = divmod(i, args.cols)
        print(f"  {rank}. cell(r{r}, c{c})  ΔNLL={img_scores[i]:.4f}")

    # Counterfactual(s)
    kdel = max(0, int(args.iterative_delete))
    if kdel > 0:
        cf_img = img
        idx_k = topk_indices(img_scores, kdel)
        for j in idx_k:
            cf_img = mask_image_region(cf_img, boxes[j], mode=args.mask_mode)
        cf_ans = generate_answer(
            model, processor, cf_img, args.question,
            max_new_tokens=args.max_new_tokens, model_id=args.model_id
        )
        cf_path = os.path.join(args.out_dir, f"counterfactual_top{kdel}_cells_masked.png")
        cf_img.save(cf_path)
        rc_list = [f"r{j//args.cols},c{j%args.cols}" for j in idx_k]
        print(f"\nCounterfactual (mask top {kdel} cells: {', '.join(rc_list)}):")
        print(f"  Answer → {cf_ans}")
        print(f"Saved → {cf_path}")
    else:
        top1 = topk_indices(img_scores, 1)[0]
        cf_img1 = mask_image_region(img, boxes[top1], mode=args.mask_mode)
        cf_ans = generate_answer(
            model, processor, cf_img1, args.question,
            max_new_tokens=args.max_new_tokens, model_id=args.model_id
        )
        cf_path = os.path.join(args.out_dir, "counterfactual_topcell_masked.png")
        cf_img1.save(cf_path)
        r, c = divmod(top1, args.cols)
        print(f"\nCounterfactual (mask top cell r{r},c{c}):")
        print(f"  Answer → {cf_ans}")
        print(f"Saved → {cf_path}")

    print("\n[INFO] Text-side importance...")
    text_scores = text_side_causal_importance(model, processor, img, args.question, ans)
    print("Top tokens by ΔNLL:")
    for tok, delta in text_scores[:10]:
        print(f"  {tok:>12s}  ΔNLL={delta:.4f}")

    # ---- build & save HTML visualization for tokens ----
    html_block = visualize_text_html(args.question, text_scores, topk=args.topk_tokens, show_bars=True)
    html_path = os.path.join(args.out_dir, "text_importance.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write("<!doctype html><meta charset='utf-8'>\n")
        f.write(f"<h3 style='font-family:Inter,Segoe UI,Arial,sans-serif;'>Question</h3>\n")
        f.write(f"<div style='font-family:Inter,Segoe UI,Arial,sans-serif; margin-bottom:8px;'>{html.escape(args.question)}</div>\n")
        f.write(html_block)
        f.write("<div style='margin-top:10px; font-size:12px; color:#666;'>"
                "Saved by run_ccme_textviz.py</div>")
    print(f"Saved → {html_path}")

    # optional JSON dump
    if args.save_json:
        jpath = os.path.join(args.out_dir, "text_importance.json")
        with open(jpath, "w", encoding="utf-8") as f:
            json.dump({"question": args.question,
                       "baseline_answer": ans,
                       "baseline_nll": base_nll,
                       "token_scores": text_scores}, f, indent=2)
        print(f"Saved → {jpath}")

    print("\nDone.")

if __name__ == "__main__":
    main()
