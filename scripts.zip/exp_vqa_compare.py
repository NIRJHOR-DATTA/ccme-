import os, json, argparse, string
import numpy as np
from tqdm import tqdm
from PIL import Image, ImageDraw, ImageFilter
import random
import torch

from ccme_vl.model_loader import load_blip2, DEFAULT_MODEL_ID
from ccme_vl.masking import preprocess_image, overlay_heatmap, mask_image_region, grid_boxes
from ccme_vl.metrics import generate_answer, answer_nll, text_side_causal_importance
from ccme_vl.ccme import topk_indices
from ccme_vl.baselines import (
    rank_image_regions_delta_nll,
    rank_image_regions_grad,
    rank_image_regions_rise,
    rank_image_regions_random,
    rank_image_regions_uniform,
)

# Optional detector
def try_detector():
    try:
        from ccme_vl.objects import detect_boxes
        return detect_boxes
    except Exception:
        return None

# ----- utils -----
def ensure_dir(p): os.makedirs(p, exist_ok=True)

def _norm(s: str) -> str:
    if s is None: return ""
    s = s.lower().strip()
    tbl = str.maketrans("", "", string.punctuation)
    s = s.translate(tbl)
    return " ".join(s.split())

def vqa_soft_acc(pred: str, answers):
    p = _norm(pred)
    cnt = sum(1 for a in answers if _norm(a) == p)
    return min(1.0, cnt/3.0)

def deletion_auc_from_deltas(deltas, steps=8):
    arr = np.array(sorted(deltas, reverse=True), dtype=float)
    if arr.size == 0: return 0.0
    k = min(len(arr), steps)
    xs = np.linspace(0, 1, k+1)
    ys = np.concatenate([[0.0], np.cumsum(arr[:k])])
    if ys[-1] > 0: ys = ys / (ys[-1] + 1e-9)
    return float(np.trapz(ys, xs))

def insertion_curve_images(img, boxes, deltas, steps=8, start="gray"):
    order = np.argsort(np.array(deltas))[::-1].tolist()
    if start == "gray":
        base = Image.new("RGB", img.size, (128, 128, 128))
    else:
        base = img.filter(ImageFilter.GaussianBlur(radius=18))
    imgs = [base]
    cur = base.copy()
    for j in order[:steps]:
        patch = img.crop(boxes[j])
        cur.paste(patch, boxes[j][:2])
        imgs.append(cur.copy())
    return imgs

def insertion_auc(model, processor, imgs, question, baseline_answer):
    nlls = [answer_nll(model, processor, im, question, baseline_answer) for im in imgs]
    logps = -np.array(nlls, dtype=float)
    x = np.linspace(0, 1, len(logps))
    y = np.maximum(0.0, logps - logps[0])  # positive gains
    if y.max() > 0: y = y / (y.max() + 1e-9)
    return float(np.trapz(y, x))

def img_path_from_id(img_root: str, image_id: int) -> str:
    return os.path.join(img_root, f"COCO_val2014_{image_id:012d}.jpg")

# ----- main -----
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--questions_json", required=True)
    ap.add_argument("--annotations_json", required=True)
    ap.add_argument("--img_root", required=True)
    ap.add_argument("--out_dir", default="runs/vqa_compare")
    ap.add_argument("--model_id", default=DEFAULT_MODEL_ID)
    ap.add_argument("--rows", type=int, default=6)
    ap.add_argument("--cols", type=int, default=6)
    ap.add_argument("--max_new_tokens", type=int, default=6)
    ap.add_argument("--limit", type=int, default=0)

    # method selection
    ap.add_argument("--method", type=str, default="delta_nll",
                    choices=["delta_nll","grad","rise","random","uniform"])
    # explainability knobs
    ap.add_argument("--mask_mode", type=str, default="blur", choices=["blur","gray","black"])
    ap.add_argument("--iterative_delete", type=int, default=3)
    ap.add_argument("--topk_metrics", type=int, default=3)
    ap.add_argument("--parsimony_threshold", type=float, default=0.5)
    ap.add_argument("--ins_steps", type=int, default=8)
    ap.add_argument("--insertion_start", type=str, default="gray", choices=["gray","blur"])

    # object boxes
    ap.add_argument("--object_boxes", action="store_true")
    ap.add_argument("--person_only", action="store_true")

    # RISE params
    ap.add_argument("--rise_N", type=int, default=64)
    ap.add_argument("--rise_cell", type=int, default=8)
    ap.add_argument("--rise_p", type=float, default=0.5)

    # NEW: fixed subset control + reproducibility
    ap.add_argument("--qid_list", type=str, default="",
                    help="Path to a txt file with one question_id per line to force the evaluated set/order")
    ap.add_argument("--save_qids", type=str, default="",
                    help="If set, save the exact processed QIDs (in order) to this path")
    ap.add_argument("--seed", type=int, default=123,
                    help="Global RNG seed for reproducibility (affects RISE/random etc.)")

    args = ap.parse_args()

    # --- strict reproducibility (as requested) ---
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
        # optional, deterministic (slower)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    ensure_dir(args.out_dir)
    print(f"[INFO] Loading model: {args.model_id}")
    model, processor = load_blip2(args.model_id)

    # Load VQA data
    with open(args.questions_json, "r", encoding="utf-8") as f:
        qlist = json.load(f)["questions"]
    with open(args.annotations_json, "r", encoding="utf-8") as f:
        anns = json.load(f)["annotations"]

    ann_map = {str(a["question_id"]): [x.get("answer","") for x in a.get("answers", [])] for a in anns}
    id_to_img = {str(a["question_id"]): a["image_id"] for a in anns}

    # ---- Build candidate pool (qid, image_id, question) ----
    pool = [(str(q["question_id"]), id_to_img[str(q["question_id"])], q["question"])
            for q in qlist if str(q["question_id"]) in ann_map]

    # If qid_list is provided, filter + keep that order
    if args.qid_list:
        with open(args.qid_list, "r", encoding="utf-8") as f:
            wanted = [line.strip() for line in f if line.strip()]
        wanted_set = set(wanted)
        # keep only those in wanted, but preserve wanted order
        wanted_idx = {qid: i for i, qid in enumerate(wanted)}
        pool = [item for item in pool if item[0] in wanted_set]
        pool.sort(key=lambda x: wanted_idx[x[0]])

    # Apply limit (preserve order)
    if args.limit and len(pool) > args.limit:
        pool = pool[:args.limit]

    # optional detector
    detector = try_detector() if args.object_boxes else None

    # aggregation
    soft_list = []; auc_img_list = []; auc_txt_list = []; ins_list = []
    comp_list = []; suff_list = []; pars_list = []
    logs = []

    for (qid, image_id, question) in tqdm(pool, total=len(pool)):
        answers = ann_map.get(qid, [])
        img_path = img_path_from_id(args.img_root, image_id)
        try:
            img = preprocess_image(img_path)
        except Exception as e:
            print(f"[WARN] skip {img_path}: {e}")
            continue

        # baseline pred
        pred = generate_answer(model, processor, img, question,
                               max_new_tokens=args.max_new_tokens, model_id=args.model_id)
        base_nll = answer_nll(model, processor, img, question, pred)
        soft_list.append(vqa_soft_acc(pred, answers))

        # boxes
        boxes = None
        if detector is not None:
            try:
                dets = detector(img, score_thr=0.7)
                if args.person_only:
                    dets = [b for b in dets if b[-1] == 1]
                boxes = [b[:4] for b in dets if (b[2] > b[0] and b[3] > b[1])]
            except Exception as e:
                print(f"[WARN] detector fail -> grid. {e}")
        if not boxes:
            w, h = img.size
            boxes = grid_boxes(w, h, args.rows, args.cols)

        # method switch
        if args.method == "delta_nll":
            img_scores, base_nll = rank_image_regions_delta_nll(
                model, processor, img, question, pred, boxes, mask_mode=args.mask_mode)
        elif args.method == "grad":
            img_scores, base_nll = rank_image_regions_grad(
                model, processor, img, question, pred, boxes)
        elif args.method == "rise":
            img_scores, base_nll = rank_image_regions_rise(
                model, processor, img, question, pred, boxes,
                N=args.rise_N, cell=args.rise_cell, p=args.rise_p)
        elif args.method == "random":
            img_scores, _ = rank_image_regions_random(boxes);  # base_nll unchanged
        else:  # uniform
            img_scores, _ = rank_image_regions_uniform(boxes);  # base_nll unchanged

        # text-side (ΔNLL token deletion is our common text baseline)
        txt_scores = text_side_causal_importance(model, processor, img, question, pred)

        # metrics
        auc_img = deletion_auc_from_deltas(img_scores, steps=min(8, len(img_scores)))
        auc_txt = deletion_auc_from_deltas([d for _, d in txt_scores], steps=min(8, len(txt_scores)))
        auc_img_list.append(auc_img); auc_txt_list.append(auc_txt)

        ins_imgs = insertion_curve_images(img, boxes, img_scores,
                                          steps=min(args.ins_steps, len(boxes)),
                                          start=args.insertion_start)
        ins_auc = insertion_auc(model, processor, ins_imgs, question, pred)
        ins_list.append(ins_auc)

        # top-K for suff/comp/pars
        K = min(args.topk_metrics, len(img_scores)) if img_scores else 0
        idx_sel = topk_indices(img_scores, K) if K > 0 else []

        # comprehensiveness: mask selected
        cf_img = img
        for j in idx_sel:
            cf_img = mask_image_region(cf_img, boxes[j], mode=args.mask_mode)
        comp = answer_nll(model, processor, cf_img, question, pred) - base_nll if idx_sel else 0.0

        # sufficiency: keep only selected
        keep = set(idx_sel)
        only_img = Image.new("RGB", img.size, (128, 128, 128))
        for j, b in enumerate(boxes):
            if j in keep:
                only_img.paste(img.crop(b), b[:2])
        suff = answer_nll(model, processor, only_img, question, pred) - base_nll if idx_sel else 0.0

        # parsimony: fraction of boxes to reach 50% of total score mass
        arr = np.array(sorted(img_scores, reverse=True), dtype=float)
        if arr.size == 0:
            pars = 1.0
        else:
            cutoff = 0.5 * arr.max()
            cum = 0.0; pars = 1.0
            for k, d in enumerate(arr, start=1):
                cum += d
                if cum >= cutoff:
                    pars = k / len(arr); break

        comp_list.append(comp); suff_list.append(suff); pars_list.append(pars)

        # artifacts
        sdir = os.path.join(args.out_dir, f"{qid}_{args.method}")
        ensure_dir(sdir)

        # overlays
        if detector is None and args.method in ["delta_nll","grad","rise","random","uniform"]:
            overlay_heatmap(img, args.rows, args.cols, img_scores).save(
                os.path.join(sdir, "image_importance_overlay.png"))
        else:
            # simple box overlay for object mode
            ov = img.copy(); draw = ImageDraw.Draw(ov, "RGBA")
            s = np.array(img_scores, dtype=np.float32)
            if s.size and s.max() > s.min():
                s = (s - s.min()) / (s.max() - s.min() + 1e-8)
            else:
                s = np.zeros_like(s)
            for b, v in zip(boxes, s):
                a = int(140 * float(v))
                draw.rectangle(b, fill=(255, 0, 0, a))
            Image.blend(img, ov, 0.45).save(os.path.join(sdir, "image_importance_overlay.png"))

        # optional CF for visualization
        if img_scores and args.iterative_delete > 0:
            idx_k = topk_indices(img_scores, args.iterative_delete)
            cf_img2 = img
            for j in idx_k:
                cf_img2 = mask_image_region(cf_img2, boxes[j], mode=args.mask_mode)
            cf_img2.save(os.path.join(sdir, f"counterfactual_top{len(idx_k)}_cells_masked.png"))

        logs.append({
            "id": qid,
            "image_id": image_id,
            "question": question,
            "answers": answers,
            "pred": pred,
            "base_nll": base_nll,
            "soft_acc": vqa_soft_acc(pred, answers),
            "auc_img": auc_img,
            "auc_txt": auc_txt,
            "insertion_auc": ins_auc,
            "comprehensiveness": comp,
            "sufficiency": suff,
            "parsimony": pars,
        })

    # Save the exact evaluated QIDs (order preserved)
    if args.save_qids:
        with open(args.save_qids, "w", encoding="utf-8") as f:
            for (qid, _, _) in pool:
                f.write(qid + "\n")

    summary = {
        "model_id": args.model_id,
        "method": args.method,
        "num_samples": len(logs),
        "vqa_soft_accuracy": float(np.mean([r["soft_acc"] for r in logs]) if logs else 0.0),
        "mean_auc_image_deletion": float(np.mean([r["auc_img"] for r in logs]) if logs else 0.0),
        "mean_auc_text_deletion": float(np.mean([r["auc_txt"] for r in logs]) if logs else 0.0),
        "mean_insertion_auc": float(np.mean([r["insertion_auc"] for r in logs]) if logs else 0.0),
        "mean_comprehensiveness": float(np.mean([r["comprehensiveness"] for r in logs]) if logs else 0.0),
        "mean_sufficiency": float(np.mean([r["sufficiency"] for r in logs]) if logs else 0.0),
        "mean_parsimony": float(np.mean([r["parsimony"] for r in logs]) if logs else 0.0),
        "rows": args.rows,
        "cols": args.cols,
        "iterative_delete": args.iterative_delete,
        "mask_mode": args.mask_mode,
        "object_boxes": args.object_boxes,
        "person_only": args.person_only,
        "ins_steps": args.ins_steps,
        "insertion_start": args.insertion_start,
        "rise": {"N": args.rise_N, "cell": args.rise_cell, "p": args.rise_p},
    }

    ensure_dir(args.out_dir)
    with open(os.path.join(args.out_dir, f"summary_{args.method}.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    with open(os.path.join(args.out_dir, f"per_sample_{args.method}.jsonl"), "w", encoding="utf-8") as f:
        for r in logs:
            f.write(json.dumps(r) + "\n")

    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
