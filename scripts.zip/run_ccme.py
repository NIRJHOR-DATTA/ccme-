import os, argparse
from pathlib import Path

from PIL import Image
from ccme_vl.model_loader import load_blip2, DEFAULT_MODEL_ID
from ccme_vl.masking import preprocess_image, overlay_heatmap, mask_image_region
from ccme_vl.metrics import generate_answer, answer_nll, text_side_causal_importance
from ccme_vl.ccme import image_side_causal_importance, topk_indices

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--question", required=True)
    ap.add_argument("--out_dir", default="runs/demo")
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--max_new_tokens", type=int, default=8)
    ap.add_argument("--model_id", type=str, default=DEFAULT_MODEL_ID)
    # NEW: iterative delete & mask mode
    ap.add_argument("--iterative_delete", type=int, default=0,
                   help="Mask top-K cells sequentially before counterfactual generation (0 = single top cell)")
    ap.add_argument("--mask_mode", type=str, default="blur",
                   choices=["blur", "gray", "black"], help="Masking style for perturbations")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    print(f"[INFO] Loading model: {args.model_id}")
    model, processor = load_blip2(args.model_id)

    print("[INFO] Reading image...")
    img = preprocess_image(args.image)

    print("[INFO] Baseline generation...")
    ans = generate_answer(
        model, processor, img, args.question,
        max_new_tokens=args.max_new_tokens, model_id=args.model_id
    )
    base_nll = answer_nll(model, processor, img, args.question, ans)
    print(f"\nQ: {args.question}\nA (baseline): {ans}\nBaseline NLL: {base_nll:.4f}")

    print("[INFO] Image-side importance...")
    img_scores, _, boxes = image_side_causal_importance(
        model, processor, img, args.question, ans, rows=args.rows, cols=args.cols
    )
    overlay = overlay_heatmap(img, args.rows, args.cols, img_scores)
    overlay_path = os.path.join(args.out_dir, "image_importance_overlay.png")
    overlay.save(overlay_path)
    print(f"Saved → {overlay_path}")

    # print top cells
    idx_sorted = topk_indices(img_scores, k=min(5, len(img_scores)))
    print("\nTop image cells by ΔNLL:")
    for rank, i in enumerate(idx_sorted, 1):
        r, c = divmod(i, args.cols)
        print(f"  {rank}. cell(r{r}, c{c})  ΔNLL={img_scores[i]:.4f}")

    # Counterfactual(s)
    k = max(0, int(args.iterative_delete))
    if k > 0:
        # iterative deletion: mask top-K sequentially
        cf_img = img
        idx_k = topk_indices(img_scores, k)
        for j in idx_k:
            cf_img = mask_image_region(cf_img, boxes[j], mode=args.mask_mode)
        cf_ans = generate_answer(
            model, processor, cf_img, args.question,
            max_new_tokens=args.max_new_tokens, model_id=args.model_id
        )
        cf_path = os.path.join(args.out_dir, f"counterfactual_top{k}_cells_masked.png")
        cf_img.save(cf_path)
        rc_list = [f"r{j//args.cols},c{j%args.cols}" for j in idx_k]
        print(f"\nCounterfactual (mask top {k} cells: {', '.join(rc_list)}):")
        print(f"  Answer → {cf_ans}")
        print(f"Saved → {cf_path}")
    else:
        # single top cell
        top1 = topk_indices(img_scores, 1)[0]
        cf_img1 = mask_image_region(img, boxes[top1], mode=args.mask_mode)
        cf_ans = generate_answer(
            model, processor, cf_img1, args.question,
            max_new_tokens=args.max_new_tokens, model_id=args.model_id
        )
        cf_path = os.path.join(args.out_dir, "counterfactual_topcell_masked.png")
        cf_img1.save(cf_path)
        r, c = divmod(top1, args.cols)
        print(f"\nCounterfactual (mask top cell r{r},c{c}):")
        print(f"  Answer → {cf_ans}")
        print(f"Saved → {cf_path}")

    print("\n[INFO] Text-side importance...")
    text_scores = text_side_causal_importance(model, processor, img, args.question, ans)
    print("Top tokens by ΔNLL:")
    for tok, delta in text_scores[:10]:
        print(f"  {tok:>12s}  ΔNLL={delta:.4f}")

    print("\nDone.")

if __name__ == "__main__":
    main()
