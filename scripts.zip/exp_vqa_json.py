import os, json, argparse, string
from pathlib import Path

import numpy as np
from tqdm import tqdm
from PIL import Image, ImageDraw, ImageFilter

from ccme_vl.model_loader import load_blip2, DEFAULT_MODEL_ID
from ccme_vl.masking import preprocess_image, overlay_heatmap, mask_image_region, grid_boxes
from ccme_vl.metrics import generate_answer, answer_nll, text_side_causal_importance
from ccme_vl.ccme import topk_indices

# -----------------------
# Utility / scoring funcs
# -----------------------
def ensure_dir(p): os.makedirs(p, exist_ok=True)

def _norm(s: str) -> str:
    if s is None: return ""
    s = s.lower().strip()
    tbl = str.maketrans("", "", string.punctuation)
    s = s.translate(tbl)
    return " ".join(s.split())

def vqa_soft_acc(pred: str, answers):
    """VQAv2 soft-acc: min(#matching-answers/3, 1)"""
    p = _norm(pred)
    cnt = sum(1 for a in answers if _norm(a) == p)
    return min(1.0, cnt/3.0)

def deletion_auc_from_deltas(deltas, steps=8) -> float:
    """
    Approximate deletion AUC from ΔNLLs (higher ΔNLL first).
    Normalizes cumulative ΔNLL and integrates over [0,1].
    """
    arr = np.array(sorted(deltas, reverse=True), dtype=float)
    if arr.size == 0:
        return 0.0
    k = min(len(arr), steps)
    xs = np.linspace(0, 1, k+1)              # fraction removed
    ys = np.concatenate([[0.0], np.cumsum(arr[:k])])
    if ys[-1] > 0:
        ys = ys / (ys[-1] + 1e-9)            # normalize
    return float(np.trapz(ys, xs))

def insertion_curve_images(img, boxes, deltas, steps=8):
    """Return list of images: start blurred, add back top cells step-by-step."""
    order = np.argsort(np.array(deltas))[::-1].tolist()
    base = img.filter(ImageFilter.GaussianBlur(radius=12))
    imgs = [base]
    cur = base.copy()
    for j in order[:steps]:
        patch = img.crop(boxes[j])
        cur.paste(patch, boxes[j][:2])
        imgs.append(cur.copy())
    return imgs  # len = steps+1

def insertion_auc(model, processor, imgs, question, baseline_answer) -> float:
    nlls = [answer_nll(model, processor, im, question, baseline_answer) for im in imgs]
    x = np.linspace(0, 1, len(nlls))
    y = np.array(nlls[0] - np.array(nlls))  # higher is better (recover confidence)
    if y.max() > 0: y = y / (y.max() + 1e-9)
    return float(np.trapz(y, x))

def comprehensiveness_score(model, processor, img, boxes, idx_sel, question,
                            baseline_answer, base_nll, mask_mode="blur") -> float:
    """
    ΔNLL after removing (masking) the top-K cells (higher is better).
    """
    cf_img = img
    for j in idx_sel:
        cf_img = mask_image_region(cf_img, boxes[j], mode=mask_mode)
    nll = answer_nll(model, processor, cf_img, question, baseline_answer)
    return float(nll - base_nll)

def sufficiency_score(model, processor, img, boxes, idx_sel, question,
                      baseline_answer, base_nll) -> float:
    """
    ΔNLL when *keeping only* the top-K cells (lower is better).
    We paste top-K patches onto a neutral background (gray).
    """
    keep = set(idx_sel)
    cf_img = Image.new("RGB", img.size, (128,128,128))  # gray background
    for j, box in enumerate(boxes):
        if j in keep:
            cf_img.paste(img.crop(box), box[:2])
    nll = answer_nll(model, processor, cf_img, question, baseline_answer)
    return float(nll - base_nll)

def parsimony_score(deltas, threshold=0.5) -> float:
    """
    Fraction of regions needed until cumulative ΔNLL reaches 'threshold' * max(ΔNLL).
    Lower = more parsimonious.
    """
    arr = np.array(sorted(deltas, reverse=True), dtype=float)
    if arr.size == 0:
        return 1.0
    cutoff = threshold * arr.max()
    cum = 0.0
    for k, d in enumerate(arr, start=1):
        cum += d
        if cum >= cutoff:
            return k / len(arr)
    return 1.0

def compute_image_deltas(model, processor, img, question, baseline_answer, boxes, mask_mode="blur"):
    """Compute ΔNLL per box given explicit boxes and chosen mask mode."""
    base_nll = answer_nll(model, processor, img, question, baseline_answer)
    deltas = []
    for box in boxes:
        masked = mask_image_region(img, box, mode=mask_mode)
        nll = answer_nll(model, processor, masked, question, baseline_answer)
        deltas.append(float(nll - base_nll))
    return deltas, base_nll

def draw_box_heatmap(img: Image.Image, boxes, scores):
    """Simple overlay for arbitrary boxes (object-box mode)."""
    if not boxes or not scores:
        return img.copy()
    s = np.array(scores, dtype=np.float32)
    if s.max() > s.min():
        s = (s - s.min()) / (s.max() - s.min() + 1e-8)
    else:
        s = np.zeros_like(s)
    overlay = img.copy()
    draw = ImageDraw.Draw(overlay, "RGBA")
    for (box, v) in zip(boxes, s):
        x0,y0,x1,y1 = box
        # red with alpha by score
        a = int(140 * float(v))
        draw.rectangle([x0,y0,x1,y1], fill=(255,0,0,a))
    return Image.blend(img, overlay, alpha=0.45)

# -----------------------
# Main
# -----------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--questions_json", required=True, help=r"D:\ccme-vl\data\questions\test.json")
    ap.add_argument("--annotations_json", required=True, help=r"D:\ccme-vl\data\annotations\test.json")
    ap.add_argument("--img_root", required=True, help=r"D:\ccme-vl\data\images\test")
    ap.add_argument("--out_dir", default="runs/vqa_json")
    ap.add_argument("--model_id", default=DEFAULT_MODEL_ID)
    ap.add_argument("--rows", type=int, default=6)
    ap.add_argument("--cols", type=int, default=6)
    ap.add_argument("--max_new_tokens", type=int, default=6)
    ap.add_argument("--limit", type=int, default=0)

    # Explainability / CF controls
    ap.add_argument("--iterative_delete", type=int, default=0,
                    help="If >0, also create a counterfactual by masking top-K cells")
    ap.add_argument("--mask_mode", type=str, default="blur",
                    choices=["blur","gray","black"], help="Mask style for image perturbations")
    ap.add_argument("--topk_metrics", type=int, default=3,
                    help="K used for sufficiency/comprehensiveness (top-K cells)")
    ap.add_argument("--parsimony_threshold", type=float, default=0.5,
                    help="Threshold (fraction of max ΔNLL) for parsimony computation")
    ap.add_argument("--ins_steps", type=int, default=8,
                    help="Number of steps for insertion curve (AUC)")

    # object boxes (optional)
    ap.add_argument("--object_boxes", action="store_true",
                    help="Use detector boxes instead of grid cells for image-side ΔNLL")
    ap.add_argument("--person_only", action="store_true",
                    help="If using object boxes, keep only 'person' boxes (label==1)")

    args = ap.parse_args()
    ensure_dir(args.out_dir)

    print(f"[INFO] Loading model: {args.model_id}")
    model, processor = load_blip2(args.model_id)

    # Load data
    with open(args.questions_json, "r") as f:
        qjson = json.load(f)
    qlist = qjson["questions"]

    with open(args.annotations_json, "r") as f:
        ajson = json.load(f)

    # Map question_id -> answers list
    ann_map = {}
    for a in ajson["annotations"]:
        qid = str(a["question_id"])
        answers = [x.get("answer","") for x in a.get("answers", [])]
        ann_map[qid] = {"answers": answers, "image_id": a["image_id"]}

    # Helper for COCO val/test naming
    def img_path_from_id(image_id: int) -> str:
        fname = f"COCO_val2014_{image_id:012d}.jpg"
        return os.path.join(args.img_root, fname)

    # Aggregation
    n = 0
    soft_list = []
    auc_img_list, auc_txt_list = [], []
    insertion_list = []
    comp_list, suff_list, pars_list = [], [],[]

    logs = []

    # Optional detector
    detector = None
    if args.object_boxes:
        try:
            from ccme_vl.objects import detect_boxes
            detector = detect_boxes
        except Exception as e:
            print(f"[WARN] object_boxes requested but detector import failed: {e}")
            detector = None

    for i, q in enumerate(tqdm(qlist, total=(args.limit or None))):
        if args.limit and i >= args.limit:
            break

        qid = str(q["question_id"])
        image_id = q["image_id"]
        question = q["question"]

        if qid not in ann_map:
            print(f"[WARN] No annotation for question_id={qid}, skipping")
            continue
        answers = ann_map[qid]["answers"]

        img_path = img_path_from_id(image_id)
        try:
            img = preprocess_image(img_path)
        except Exception as e:
            print(f"[WARN] Could not read {img_path}: {e}")
            continue

        # Baseline
        pred = generate_answer(
            model, processor, img, question,
            max_new_tokens=args.max_new_tokens, model_id=args.model_id
        )
        base_nll = answer_nll(model, processor, img, question, pred)
        soft = vqa_soft_acc(pred, answers)
        soft_list.append(soft)

        # Decide boxes: object boxes if available else grid
        boxes = None
        if detector is not None:
            dets = detector(img, score_thr=0.7)  # (x0,y0,x1,y1,label)
            if args.person_only:
                dets = [b for b in dets if b[-1] == 1]
            boxes = [b[:4] for b in dets if (b[2] > b[0] and b[3] > b[1])]
        if not boxes:
            w, h = img.size
            boxes = grid_boxes(w, h, args.rows, args.cols)

        # Image-side ΔNLL over chosen boxes
        img_scores, base_nll_check = compute_image_deltas(
            model, processor, img, question, pred, boxes, mask_mode=args.mask_mode
        )
        # sanity
        base_nll = base_nll_check

        # Text-side ΔNLL
        txt_scores = text_side_causal_importance(model, processor, img, question, pred)

        # AUCs
        auc_img = deletion_auc_from_deltas(img_scores, steps=min(8, len(img_scores)))
        auc_txt = deletion_auc_from_deltas([d for _, d in txt_scores], steps=min(8, len(txt_scores)))
        auc_img_list.append(auc_img); auc_txt_list.append(auc_txt)

        # Insertion AUC (image)
        ins_imgs = insertion_curve_images(img, boxes, img_scores, steps=min(args.ins_steps, len(boxes)))
        ins_auc = insertion_auc(model, processor, ins_imgs, question, pred)
        insertion_list.append(ins_auc)

        # K selection for metrics
        K = min(args.topk_metrics, len(img_scores)) if img_scores else 0
        idx_sel = topk_indices(img_scores, K) if K > 0 else []

        # Comprehensiveness / Sufficiency / Parsimony
        comp = comprehensiveness_score(model, processor, img, boxes, idx_sel,
                                       question, pred, base_nll, mask_mode=args.mask_mode) if idx_sel else 0.0
        suff = sufficiency_score(model, processor, img, boxes, idx_sel,
                                 question, pred, base_nll) if idx_sel else 0.0
        pars = parsimony_score(img_scores, threshold=args.parsimony_threshold) if img_scores else 1.0
        comp_list.append(comp); suff_list.append(suff); pars_list.append(pars)

        # Artifacts
        sdir = os.path.join(args.out_dir, qid); ensure_dir(sdir)
        if detector is None:  # grid overlay
            # Need rows/cols for overlay_heatmap; infer from count
            # (we already used args.rows/cols to make boxes)
            overlay_heatmap(img, args.rows, args.cols, img_scores).save(os.path.join(sdir, "image_importance_overlay.png"))
        else:  # object box overlay
            draw_box_heatmap(img, boxes, img_scores).save(os.path.join(sdir, "image_importance_overlay.png"))

        # Optional counterfactual(s) for qualitative inspection
        if img_scores:
            if args.iterative_delete > 0:
                idx_k = topk_indices(img_scores, args.iterative_delete)
                cf_img = img
                for j in idx_k:
                    cf_img = mask_image_region(cf_img, boxes[j], mode=args.mask_mode)
                cf_pred = generate_answer(
                    model, processor, cf_img, question,
                    max_new_tokens=args.max_new_tokens, model_id=args.model_id
                )
                cf_img.save(os.path.join(sdir, f"counterfactual_top{len(idx_k)}_cells_masked.png"))
            else:
                top1 = topk_indices(img_scores, 1)[0]
                cf_img1 = mask_image_region(img, boxes[top1], mode=args.mask_mode)
                cf_pred = generate_answer(
                    model, processor, cf_img1, question,
                    max_new_tokens=args.max_new_tokens, model_id=args.model_id
                )
                cf_img1.save(os.path.join(sdir, "counterfactual_topcell_masked.png"))
        else:
            cf_pred = pred

        # Log row
        logs.append({
            "id": qid,
            "image_id": image_id,
            "image_path": img_path,
            "question": question,
            "answers": answers,
            "pred": pred,
            "soft_acc": soft,
            "base_nll": base_nll,
            "auc_img": auc_img,
            "auc_txt": auc_txt,
            "insertion_auc": ins_auc,
            "comprehensiveness": comp,
            "sufficiency": suff,
            "parsimony": pars,
            "cf_pred": cf_pred,
            "used_object_boxes": bool(detector is not None),
        })

        n += 1

    # Summary
    summary = {
        "model_id": args.model_id,
        "num_samples": n,
        "vqa_soft_accuracy": float(np.mean(soft_list) if soft_list else 0),
        "mean_auc_image_deletion": float(np.mean(auc_img_list) if auc_img_list else 0),
        "mean_auc_text_deletion": float(np.mean(auc_txt_list) if auc_txt_list else 0),
        "mean_insertion_auc": float(np.mean(insertion_list) if insertion_list else 0),
        "mean_comprehensiveness": float(np.mean(comp_list) if comp_list else 0),
        "mean_sufficiency": float(np.mean(suff_list) if suff_list else 0),
        "mean_parsimony": float(np.mean(pars_list) if pars_list else 0),
        "rows": args.rows, "cols": args.cols,
        "iterative_delete": args.iterative_delete,
        "mask_mode": args.mask_mode,
        "topk_metrics": args.topk_metrics,
        "parsimony_threshold": args.parsimony_threshold,
        "object_boxes": args.object_boxes,
        "person_only": args.person_only,
        "ins_steps": args.ins_steps,
    }

    with open(os.path.join(args.out_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    with open(os.path.join(args.out_dir, "per_sample.jsonl"), "w") as f:
        for r in logs:
            f.write(json.dumps(r) + "\n")

    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
