import os, json, argparse
from pathlib import Path
from tqdm import tqdm
from PIL import Image

from ccme_vl.model_loader import load_blip2, DEFAULT_MODEL_ID
from ccme_vl.masking import preprocess_image, overlay_heatmap, grid_boxes, mask_image_region
from ccme_vl.metrics import generate_answer, answer_nll, text_side_causal_importance
from ccme_vl.ccme import image_side_causal_importance, topk_indices
from ccme_vl.data import VQAv2Dataset
from ccme_vl.eval import vqa_soft_acc, deletion_auc_from_deltas

def ensure_dir(p): os.makedirs(p, exist_ok=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ann", required=True, help="v2_mscoco_val2014_annotations.json")
    ap.add_argument("--ques", required=True, help="v2_OpenEnded_mscoco_val2014_questions.json")
    ap.add_argument("--img_root", required=True)
    ap.add_argument("--out_dir", default="runs/vqav2_exp")
    ap.add_argument("--model_id", default=DEFAULT_MODEL_ID)
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--max_new_tokens", type=int, default=6)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    ensure_dir(args.out_dir)

    print(f"[INFO] Loading model: {args.model_id}")
    model, processor = load_blip2(args.model_id)
    ds = VQAv2Dataset(args.ann, args.ques, args.img_root)

    n = 0
    soft_sum = 0.0
    auc_img_list, auc_txt_list = [], []
    logs = []

    for i, s in enumerate(tqdm(ds, total=(args.limit or None))):
        if args.limit and i >= args.limit: break

        try:
            img = preprocess_image(s.image_path)
        except Exception as e:
            print(f"[WARN] skip {s.image_path}: {e}")
            continue

        # Predict
        pred = generate_answer(model, processor, img, s.question, max_new_tokens=args.max_new_tokens, model_id=args.model_id)
        base_nll = answer_nll(model, processor, img, s.question, pred)

        # VQAv2 soft accuracy
        soft = vqa_soft_acc(pred, s.answers)
        soft_sum += soft

        # Explainability (ΔNLL)
        img_scores, _, boxes = image_side_causal_importance(model, processor, img, s.question, pred,
                                                            rows=args.rows, cols=args.cols)
        text_scores = text_side_causal_importance(model, processor, img, s.question, pred)

        auc_img = deletion_auc_from_deltas(img_scores, steps=min(8, len(img_scores)))
        auc_txt = deletion_auc_from_deltas([d for _, d in text_scores], steps=min(8, len(text_scores)))
        auc_img_list.append(auc_img); auc_txt_list.append(auc_txt)

        # save artifacts
        sid = s.qid
        sdir = os.path.join(args.out_dir, sid); ensure_dir(sdir)
        overlay_heatmap(img, args.rows, args.cols, img_scores).save(os.path.join(sdir, "image_importance_overlay.png"))

        # counterfactual top region
        if img_scores:
            top_idx = topk_indices(img_scores, 1)[0]
            cf_img = mask_image_region(img, boxes[top_idx])
            cf_pred = generate_answer(model, processor, cf_img, s.question, max_new_tokens=args.max_new_tokens, model_id=args.model_id)
        else:
            cf_pred = pred

        logs.append({
            "id": sid,
            "image_path": s.image_path,
            "question": s.question,
            "answers": s.answers,
            "pred": pred,
            "soft_acc": soft,
            "base_nll": base_nll,
            "auc_img": auc_img,
            "auc_txt": auc_txt,
            "cf_pred_top_region_masked": cf_pred
        })

        n += 1

    summary = {
        "model_id": args.model_id,
        "num_samples": n,
        "vqa_soft_accuracy": soft_sum / max(n,1),
        "mean_auc_image_deletion": float(sum(auc_img_list)/max(len(auc_img_list),1)),
        "mean_auc_text_deletion": float(sum(auc_txt_list)/max(len(auc_txt_list),1)),
        "rows": args.rows, "cols": args.cols
    }
    with open(os.path.join(args.out_dir, "summary.json"), "w") as f: json.dump(summary, f, indent=2)
    with open(os.path.join(args.out_dir, "per_sample.jsonl"), "w") as f:
        for r in logs: f.write(json.dumps(r)+"\n")

    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
