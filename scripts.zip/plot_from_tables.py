#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Plot CCME-VL results from the two tables.
No file I/O needed: the metrics are embedded below.

Generates:
  - bar_mean_auc_image_deletion.png
  - bar_mean_auc_text_deletion.png
  - bar_mean_insertion_auc.png
  - bar_mean_comprehensiveness.png
  - bar_mean_sufficiency.png
  - bar_mean_parsimony.png
  - scatter_comp_vs_suff.png
  - (optional) per-method panels by mask

Usage:
  python scripts/plot_from_tables.py
"""

import os
import math
import numpy as np
import matplotlib.pyplot as plt

OUT_DIR = "D:\ccme-vl\out_plots"
os.makedirs(OUT_DIR, exist_ok=True)

# -----------------------------
# Data from training
# -----------------------------
# For methods with "N/A" AUC_text-del in the text,
# we’ll encode as np.nan to avoid misleading bars.

INSTRUCTBLIP = [
    # method, mask, vqa, auc_img_del, auc_text_del, auc_ins, comp, suff, pars
    ("delta_nll", "blur", 0.486, 0.632, 0.573, 0.368,  0.185, 0.139, 0.028),
    ("grad",      "blur", 0.486, np.nan, np.nan, 0.302, 0.018, 0.178, 1.000),
    ("rise",      "blur", 0.486, 0.523, np.nan, 0.290, -0.029, 0.228, 0.028),
    ("random",    "blur", 0.486, 0.520, np.nan, 0.327, 0.016, 0.188, 0.028),
    ("uniform",   "blur", 0.486, 0.500, np.nan, 0.302, 0.018, 0.178, 0.028),

    ("delta_nll", "gray", 0.486, 0.641, 0.573, 0.377,  0.202, 0.128, 0.030),
    ("grad",      "gray", 0.486, np.nan, np.nan, 0.302, 0.019, 0.178, 1.000),
    ("rise",      "gray", 0.486, 0.523, np.nan, 0.290, -0.033, 0.228, 0.028),
    ("random",    "gray", 0.486, 0.520, np.nan, 0.327, 0.024, 0.188, 0.028),
    ("uniform",   "gray", 0.486, 0.500, np.nan, 0.302, 0.019, 0.178, 0.028),
]

BLIP2 = [
    ("delta_nll", "gray", 0.282, 0.665, 0.620, 0.281,  0.107,  0.012, 0.036),
    ("rise",      "gray", 0.282, 0.523, np.nan, 0.215, -0.048,  0.048, 0.028),
    ("random",    "gray", 0.282, 0.520, np.nan, 0.267, -0.014,  0.026, 0.028),
    ("uniform",   "gray", 0.282, 0.500, np.nan, 0.258, -0.012, -0.005, 0.028),
    ("grad",      "gray", 0.282, np.nan, np.nan, 0.258, -0.012, -0.005, 1.000),

    ("delta_nll", "blur", 0.282, 0.673, 0.620, 0.274,  0.125,  0.013, 0.030),
    ("rise",      "blur", 0.282, 0.523, np.nan, 0.215, -0.030,  0.048, 0.028),
    ("random",    "blur", 0.282, 0.520, np.nan, 0.267,  0.009,  0.026, 0.028),
    ("uniform",   "blur", 0.282, 0.500, np.nan, 0.258,  0.007, -0.005, 0.028),
    ("grad",      "blur", 0.282, np.nan, np.nan, 0.258,  0.007, -0.005, 1.000),
]

DATASETS = {
    "InstructBLIP (Salesforce/instructblip-flan-t5-xl)": INSTRUCTBLIP,
    "BLIP-2 (Salesforce/blip2-flan-t5-xl)": BLIP2,
}

PRETTY = {
    "delta_nll": r"$\Delta$NLL (ours)",
    "grad": "Grad",
    "rise": "RISE",
    "random": "Random",
    "uniform": "Uniform",
}

METRICS = [
    ("auc_img_del", "AUC_img-del (↑)"),
    ("auc_text_del","AUC_text-del (↑)"),
    ("auc_ins",     "AUC_ins (↑)"),
    ("comp",        "Comprehensiveness (↑)"),
    ("suff",        "Sufficiency (↓)"),
    ("pars",        "Parsimony (↓)"),
]

# -----------------------------
# Utilities
# -----------------------------
def to_records(rows):
    """Turn tuples into dicts for clarity."""
    keys = ["method","mask","vqa","auc_img_del","auc_text_del","auc_ins","comp","suff","pars"]
    out = []
    for r in rows:
        out.append({k:v for k,v in zip(keys, r)})
    return out

def bar_by_group(records, metric_key, y_label, out_path):
    """
    For each dataset: panels split by mask (blur/gray),
    bars = methods.
    """
    # group by (dataset, mask)
    panels = []
    for ds_name, recs in records.items():
        # split by mask
        masks = sorted(list({r["mask"] for r in recs}))
        for m in masks:
            subset = [r for r in recs if r["mask"] == m]
            # keep fixed method order for readability
            methods_order = ["delta_nll","rise","random","uniform","grad"]
            subset = sorted(subset, key=lambda x: methods_order.index(x["method"]) if x["method"] in methods_order else 99)
            panels.append((f"{ds_name} | mask={m}", subset))

    n_panels = len(panels)
    ncols = min(2, n_panels)
    nrows = math.ceil(n_panels / ncols)

    plt.figure(figsize=(6.4*ncols, 4.2*nrows), dpi=160)
    for i, (title, subset) in enumerate(panels, 1):
        ax = plt.subplot(nrows, ncols, i)
        x = np.arange(len(subset))
        vals = [r[metric_key] for r in subset]
        labels = [PRETTY.get(r["method"], r["method"]) for r in subset]
        ax.bar(x, vals)
        ax.set_xticks(x); ax.set_xticklabels(labels, rotation=25, ha="right")
        ax.set_ylabel(y_label)
        ax.set_title(title)
        ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    plt.tight_layout()
    plt.savefig(out_path, bbox_inches="tight")
    plt.close()
    print(f"[SAVE] {out_path}")

def comp_suff_scatter_all(records, out_path):
    """
    One panel per dataset+mask. Points = methods.
    X = suff (lower better), Y = comp (higher better).
    """
    panels = []
    for ds_name, recs in records.items():
        for m in sorted(list({r["mask"] for r in recs})):
            subset = [r for r in recs if r["mask"] == m]
            panels.append((f"{ds_name} | mask={m}", subset))

    n_panels = len(panels)
    ncols = min(2, n_panels)
    nrows = math.ceil(n_panels / ncols)

    plt.figure(figsize=(6.4*ncols, 4.6*nrows), dpi=170)
    for i, (title, subset) in enumerate(panels, 1):
        ax = plt.subplot(nrows, ncols, i)
        for r in subset:
            x = r["suff"]; y = r["comp"]
            ax.scatter([x],[y])
            ax.annotate(PRETTY.get(r["method"], r["method"]), (x,y), textcoords="offset points", xytext=(6,4), fontsize=9)
        ax.set_xlabel("Sufficiency (↓ better)")
        ax.set_ylabel("Comprehensiveness (↑ better)")
        ax.set_title(title)
        ax.grid(True, linestyle=":", alpha=0.5)
    plt.tight_layout()
    plt.savefig(out_path, bbox_inches="tight")
    plt.close()
    print(f"[SAVE] {out_path}")

# -----------------------------
# Main
# -----------------------------
def main():
    # normalize to dict-of-records
    records = {ds: to_records(rows) for ds, rows in DATASETS.items()}

    # Bars for each metric
    for key, label in METRICS:
        outp = os.path.join(OUT_DIR, f"bar_mean_{key}.png")
        bar_by_group(records, key, label, outp)

    # Comp vs Suff scatter
    comp_suff_scatter_all(records, os.path.join(OUT_DIR, "scatter_comp_vs_suff.png"))

    print("[DONE] Plots generated in:", OUT_DIR)

if __name__ == "__main__":
    main()
